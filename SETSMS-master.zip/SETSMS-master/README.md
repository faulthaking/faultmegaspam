# mega spam 
Es una herramienta de automatización de spam de mensajes de texto a un número telefónico de manera gratuita y anónima. Utiliza las herramientas (Quack - Impulse) para realizar el spam, además, tiene la función de guardar números telefónicos en una lista negra (blacklist) y realizar el spam a todos los números de la lista negra consecutivamente.
# DEMO
# PLATAFORMAS
[√] Termux
#
[√] Kali Linux
#
[√] Parrot Sec
# REQUISITOS
[-] git
#
[-] python3
# INSTALACIÓN
git clone https://github.com/faulthaking/faultmegaspam.git
#
cd faultmegaspam
#
chmod faultmegaspam.sh
#
bash megaspam.sh
# Creado por fault
